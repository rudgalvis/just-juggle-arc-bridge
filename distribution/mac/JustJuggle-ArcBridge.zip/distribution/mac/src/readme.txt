This application is developed by Rokas Rudgalvis <rokas@rudgalvis.com>,
a developer who is currently not signed up for Apple Developer Program.
This app is thus automatically blocked by macOS. To run the application
you need to follow these steps:


First do the regular install:
1. Double click JustJuggle-ArcBridge-beta.dmg
2. Drag the Just Juggle to Applications folder


Then remove attributes which apple added once downloaded from the internet:
3. Double click allow-early-stage-app.command


You can now run the application.

If you have any issues, please contact me at rokas@rudgalvis.com