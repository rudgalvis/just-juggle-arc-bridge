Watch video instructions: https://youtu.be/J-kEcVpkFNk

This application is developed by Rokas Rudgalvis <rokas@rudgalvis.com>,
a developer who is currently not signed up for Apple Developer Program.
This app is thus automatically blocked by macOS. To run the application
you need to follow these steps:

First do the regular install:
1. Double click JustJuggle-ArcBridge-beta.dmg
2. Drag the Just Juggle to Applications folder

The app will not work yet, because it is blocked by macOS. To unblock it:
1. Open the terminal
2. Type the following command:
    xattr -r -d com.apple.quarantine /Applications/Just\ Juggle\ -\ Arc\ Bridge.app

You can now run the application.

If you have any issues, please contact me at rokas@rudgalvis.com